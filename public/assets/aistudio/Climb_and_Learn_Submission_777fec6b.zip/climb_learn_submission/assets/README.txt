Optional assets folder. Add ALonelyCherryTree.mp3 here if you want background music; the game runs without it.
