CLIMB & LEARN
==============

Submission package for the Climb & Learn 2D platform game.

HOW TO RUN
----------
1. Extract the ZIP file.
2. Open index.html in a modern browser (Chrome, Edge, or Firefox).
3. Internet access is required to load the p5.js libraries from CDN.

CONTROLS
--------
A / D or Left / Right arrows : Move
Hold W, Up arrow, or Space   : Charge jump; release to jump
E                            : Talk to the character
R                            : Return to last checkpoint
T                            : Replay the latest study tip
M                            : Toggle sound

GAME OBJECTIVE
--------------
Climb to the top, collect the key to unlock the gate, and discover six
study tips placed at checkpoints.

PROJECT STRUCTURE
-----------------
index.html       Main runnable game
src/sketch.js    Game source code
README.txt       Run instructions and controls
SUBMISSION.txt   Short project description for reviewers

NOTE
----
Background music is optional and is not bundled. Sound effects are generated
by the game. An internet connection is needed for the p5.js CDN scripts.
