// ============================================================
// CLIMB & LEARN - a p5.js platformer
// Reach the top, grab the key, and collect study tips from
// the checkpoint flags along the way.
// Needs p5.js + p5.sound and assets/ALonelyCherryTree.mp3
// ============================================================
// ---------- tuning ----------
const TOP_Y = -1650; // going above this height = you win
const MAX_SPEED = 15; // speed cap (prevents falling through platforms)
const WALK_SPEED = 2.2;
const AIR_CONTROL = 0.03; // tiny steering while airborne (set 0 for none)
const CHARGE_RATE = 0.033; // how fast the jump charges
const MIN_JUMP = 0.3; // minimum charge needed to jump
const FORCE_DECAY = 0.9;
const TIP_DURATION = 540; // frames the tip panel stays (~9 s at 60 fps)
// ---------- content (edit freely) ----------
const NPC_LINES = [
"Hi there!",
"Another jumper, I see!",
"You know how to move, right?",
"Press A and D to walk left and right.",
"Hold W to charge a jump, then let go!",
"Hold A or D while charging to jump sideways.",
"Try it. You'll get the hang of it!",
"One more thing: find the key on your way up.",
"It's very important!",
"Flags on the way hold study tips. Grab them all!",
"Good luck!",
];
// One tip per checkpoint, in climbing order.
const TIPS = [
{
title: "Pomodoro Technique",
text: "Study for 25 minutes, then rest for 5. Short focused sprints beat marathon sessions.",
},
{
title: "Active Recall",
text: "Close the book and quiz yourself. Pulling facts out of memory beats re-reading.",
},
{
title: "Spaced Repetition",
text: "Review at growing gaps: 1 day, 3 days, 1 week, 1 month. Spacing makes memories last.",
},
{
title: "Sleep Is Study Time",
text: "Sleep helps your brain lock in what you learned, so all-nighters often backfire.",
},
{
title: "Teach It to Learn It",
text: "Explain a topic out loud as if teaching a friend. Where you stumble is what to review.",
},
{
title: "Phone Out of Sight",
text: "Keep your phone out of sight while studying. Fewer interruptions mean deeper focus.",
},
];
// [x, y, width, height] with (x, y) = top-left corner
const PLATFORM_DATA = [
[33, 364, 433, 36], // 0 ground
[-10, 217, 149, 183], // 1
[361, 217, 149, 183], // 2
[186, 65, 124, 40], // 3
[303, -46, 108, 40], // 4
[419, -146, 91, 40], // 5
[261, -146, 84, 40], // 6
[124, -245, 81, 74], // 7
[-10, -271, 98, 95], // 8
[335, -412, 55, 19], // 9
[213, -412, 55, 19], // 10
[437, -461, 73, 19], // 11
[195, -491, 162, 19], // 12
[297, -510, 60, 19], // 13
[165, -602, 66, 60], // 14
[-10, -632, 76, 24], // 15
[173, -760, 83, 75], // 16
[-10, -879, 81, 23], // 17
[449, -966, 61, 17], // 18
[10, -1071, 55, 23], // 19
[208, -1205, 83, 75], // 20
[-10, -1228, 50, 23], // 21
[455, -1310, 55, 23], // 22
[291, -1388, 55, 23], // 23
[153, -1419, 55, 23], // 24
[10, -1451, 55, 23], // 25
[153, -1509, 188, 21], // 26
[-10, -1901, 196, 316], // 27
[300, -1901, 210, 316], // 28
[-15, -1585, 20, 1985], // 29 left wall
[495, -1585, 20, 1985], // 30 right wall
];
// Indexes into PLATFORM_DATA: landing on one of these activates a checkpoint.
// Change the numbers to move a flag to another platform.
const CHECKPOINT_PLATFORMS = [3, 7, 12, 16, 20, 26];
// ---------- globals ----------
let state = "menu"; // menu | game | win
let backMusic;
let gravity;
let player, platforms, lockedPlatform, keyItem, npc, checkpoints;
let particles = [];
let stars = [];
let clouds = [];
let camY = 0;
let tipsFound = [];
let lastCheckpoint = null;
let lastTip = -1;
let tipShown = 0;
let tipTimer = 0;
let toastText = "";
let toastTimer = 0;
let falls = 0;
let runStart = 0;
let winTime = 0;
let muted = false;
let audioReady = false;
let sfxOsc, sfxEnv;
// ============================================================
// p5 lifecycle
// ============================================================
function preload() {
  // Optional background music omitted so the game runs without extra assets.
}
function setup() {
createCanvas(500, 400);
frameRate(60);
rectMode(CENTER);
gravity = createVector(0, 0.5);
randomSeed(7); // same starry sky every run
for (let i = 0; i < 70; i++) {
stars.push({ x: random(width), y: random(height * 0.8), r: random(1, 2.5), p: random(TWO_PI) });
}
for (let i = 0; i < 5; i++) {
clouds.push({ x: random(width), y: random(40, 260), s: random(0.1, 0.35), w: random(60, 110) });
}
randomSeed(Date.now());
setupGame();
}
function setupGame() {
player = new Player(width / 2, height / 2);
platforms = [];
for (const d of PLATFORM_DATA) {
platforms.push(new Platform(d[0] + d[2] / 2, d[1] + d[3] / 2, d[2], d[3]));
}
checkpoints = CHECKPOINT_PLATFORMS.map((pi, i) => new Checkpoint(platforms[pi], i));
lockedPlatform = new Platform(width / 2, -1600, 150, 40, true);
platforms.push(lockedPlatform);
keyItem = new KeyItem(38, -1090);
npc = new NPC(width / 2 + width / 6, 351.5);
particles = [];
tipsFound = new Array(TIPS.length).fill(false);
lastCheckpoint = null;
lastTip = -1;
tipTimer = 0;
toastTimer = 0;
falls = 0;
camY = height * floor(player.pos.y / height);
}
function draw() {
rectMode(CENTER);
if (state === "menu") {
drawMenu();
return;
}
if (state === "game") updateGame();
updateParticles();
if (state === "win" && frameCount % 2 === 0) spawnConfetti();
// camera: flips one screen at a time, with a quick ease
const target = height * floor(player.pos.y / height);
camY = lerp(camY, target, 0.2);
if (abs(camY - target) < 0.5) camY = target;
const t = constrain(map(player.pos.y, height, TOP_Y, 0, 1), 0, 1);
drawSky(t);
push();
translate(0, -camY);
for (const p of platforms) p.draw();
for (const c of checkpoints) c.draw();
npc.draw();
keyItem.draw();
player.draw();
drawParticles();
pop();
drawHUD();
drawTipPanel();
drawToast();
if (state === "win") drawWinOverlay();
}
function updateGame() {
player.update();
for (const c of checkpoints) c.update();
keyItem.update();
npc.update();
if (player.pos.y > height + 60) respawn(); // safety net if you somehow fall out
if (player.pos.y < TOP_Y) winGame();
}
// ============================================================
// Input
// ============================================================
function keyPressed() {
const k = (key || "").toLowerCase();
if (keyCode === ENTER) startOrRestart();
if (k === "m") toggleMute();
if (state === "game") {
if (k === "e") npc.talk();
if (k === "r") respawn();
if (k === "t") replayTip();
}
// stop the page from scrolling with space / arrow keys
if ([32, UP_ARROW, DOWN_ARROW, LEFT_ARROW, RIGHT_ARROW].includes(keyCode)) return false;
}
function mousePressed() {
startOrRestart();
}
function startOrRestart() {
if (state === "menu") {
startAudio(); // audio may only start after a user gesture
beginRun();
} else if (state === "win") {
beginRun();
}
}
function beginRun() {
setupGame();
runStart = millis();
state = "game";
}
function winGame() {
state = "win";
winTime = millis() - runStart;
burst(player.pos.x, player.pos.y, 40, [255, 220, 80], 4);
[523, 659, 784, 1047, 1319].forEach((f, i) => sfx(f, "triangle", i * 110));
}
function respawn() {
const cp = lastCheckpoint;
player.pos.set(cp ? cp.x : width / 2, cp ? cp.y - player.h / 2 - 1 : height / 2);
player.vel.set(0, 0);
player.force.set(0, 0);
player.charge = 0;
player.lastLandY = null;
camY = height * floor(player.pos.y / height);
burst(player.pos.x, player.pos.y, 12, [180, 200, 255], 2);
toast(cp ? "Back at checkpoint " + (cp.tip + 1) : "Back at the start");
sfx(200, "sawtooth");
}
// ============================================================
// Audio
// ============================================================
function startAudio() {
userStartAudio();
if (audioReady) return;
sfxOsc = new p5.Oscillator(440, "square");
sfxOsc.amp(0);
sfxOsc.start();
sfxEnv = new p5.Envelope();
sfxEnv.setADSR(0.005, 0.08, 0, 0.05);
sfxEnv.setRange(0.2, 0);
audioReady = true;
if (typeof backMusic !== "undefined" && backMusic && backMusic.isLoaded()) {
backMusic.setVolume(0.5);
backMusic.loop();
}
}
function sfx(freq, type = "square", delay = 0) {
if (!audioReady || muted) return;
setTimeout(() => {
sfxOsc.setType(type);
sfxOsc.freq(freq);
sfxEnv.play(sfxOsc);
}, delay);
}
function toggleMute() {
muted = !muted;
if (audioReady && typeof backMusic !== "undefined" && backMusic && backMusic.isLoaded()) backMusic.setVolume(muted ? 0 : 0.5);
toast(muted ? "Sound off" : "Sound on");
}
// ============================================================
// Player
// ============================================================
class Player {
constructor(x, y) {
this.pos = createVector(x, y);
this.vel = createVector(0, 0);
this.force = createVector(0, 0);
this.w = 25;
this.h = 25;
this.facing = 1; // 1 = right, -1 = left
this.charge = 0; // 0..1
this.grounded = false;
this.ground = null; // platform we are standing on
this.lastDir = 0;
this.lastDirFrame = -999;
this.lastLandY = null;
this.sx = 1; // squash & stretch
this.sy = 1;
}
update() {
const left = keyIsDown(65) || keyIsDown(LEFT_ARROW);
const right = keyIsDown(68) || keyIsDown(RIGHT_ARROW);
const wantsJump = keyIsDown(87) || keyIsDown(UP_ARROW) || keyIsDown(32);
const dir = (right ? 1 : 0) - (left ? 1 : 0);
if (dir !== 0) {
this.facing = dir;
this.lastDir = dir;
this.lastDirFrame = frameCount;
}
// --- input ---
if (this.grounded) {
if (wantsJump) {
this.charge = min(this.charge + CHARGE_RATE, 1);
this.vel.x = 0.5; // crouch: stop sliding while charging
} else {
if (this.charge > MIN_JUMP) this.jump();
else if (dir !== 0) this.vel.x = dir * WALK_SPEED;
this.charge = 0;
}
} else {
this.charge = 0;
this.vel.x += dir * AIR_CONTROL;
}
// --- physics ---
this.vel.add(gravity);
this.vel.add(this.force);
this.force.mult(FORCE_DECAY);
this.vel.x = constrain(this.vel.x, -MAX_SPEED, MAX_SPEED);
this.vel.y = constrain(this.vel.y, -MAX_SPEED, MAX_SPEED);
const wasGrounded = this.grounded;
this.grounded = false;
this.ground = null;
// move on X, then resolve
this.pos.x += this.vel.x;
for (const p of platforms) {
if (!p.overlaps(this)) continue;
if (this.vel.x > 0) this.pos.x = p.pos.x - p.w / 2 - this.w / 2;
else if (this.vel.x < 0) this.pos.x = p.pos.x + p.w / 2 + this.w / 2;
this.vel.x = 0;
this.force.x = 0;
}
// move on Y, then resolve
const impact = this.vel.y;
this.pos.y += this.vel.y;
for (const p of platforms) {
if (!p.overlaps(this)) continue;
if (this.vel.y > 0) {
this.pos.y = p.top - this.h / 2; // landed on top
this.grounded = true;
this.ground = p;
} else if (this.vel.y < 0) {
this.pos.y = p.pos.y + p.h / 2 + this.h / 2; // bumped head
this.force.y = 0;
}
this.vel.y = 0;
}
if (this.grounded) {
if (dir === 0) {
this.vel.x = 0.75; // ground friction
if (abs(this.vel.x) < 0.05) this.vel.x = 0;
}
if (!wasGrounded) this.onLand(impact);
}
}
jump() {
// jump sideways only if a direction key was held (or just released)
const aim = frameCount - this.lastDirFrame <= 8 ? this.lastDir : 0;
if (aim !== 0) this.facing = aim;
this.force.x = this.charge * aim;
this.force.y = -this.charge * 2.5;
this.sx = 0.8;
this.sy = 1.3;
sfx(250 + this.charge * 300, "square");
}
onLand(impact) {
// count a "fall" when we land clearly lower than the last landing
if (this.lastLandY !== null && this.pos.y > this.lastLandY + 80) falls++;
this.lastLandY = this.pos.y;
if (impact > 3) {
burst(this.pos.x, this.pos.y + this.h / 2, 8, [220, 210, 190], 1.5);
this.sx = 1.25;
this.sy = 0.75;
sfx(110, "triangle");
}
}
draw() {
this.sx = lerp(this.sx, 1, 0.2);
this.sy = lerp(this.sy, 1, 0.2);
push();
translate(this.pos.x, this.pos.y + this.h / 2); // pivot at the feet
scale(this.sx, this.sy);
stroke(0);
fill(255, 80, 100);
rect(0, -this.h / 2, this.w, this.h, 5);
fill(0);
noStroke();
rect(5 * this.facing, -this.h / 2 - 5, 4, 4); // eye
pop();
if (this.charge > 0) this.drawChargeBar();
}
drawChargeBar() {
push();
rectMode(CORNER);
const bw = 34;
const bx = this.pos.x - bw / 2;
const by = this.pos.y - this.h / 2 - 14;
noStroke();
fill(0, 0, 0, 150);
rect(bx - 1, by - 1, bw + 2, 7, 3);
let c = lerpColor(color(80, 220, 100), color(255, 70, 70), this.charge);
if (this.charge >= 1 && frameCount % 10 < 5) c = color(255);
fill(c);
rect(bx, by, bw * this.charge, 5, 2);
stroke(255);
strokeWeight(1);
line(bx + bw * MIN_JUMP, by - 2, bx + bw * MIN_JUMP, by + 7); // minimum-jump tick
pop();
}
}
// ============================================================
// World objects
// ============================================================
class Platform {
constructor(x, y, w, h, locked = false) {
this.pos = createVector(x, y);
this.w = w;
this.h = h;
this.locked = locked;
}
get top() {
return this.pos.y - this.h / 2;
}
overlaps(p) {
return (
abs(p.pos.x - this.pos.x) < (this.w + p.w) / 2 - 0.001 &&
abs(p.pos.y - this.pos.y) < (this.h + p.h) / 2 - 0.001
);
}
draw() {
// skip anything that is off screen
if (this.pos.y + this.h / 2 < camY - 5 || this.pos.y - this.h / 2 > camY + height + 5) return;
push();
noStroke();
if (this.locked) {
fill(110, 120, 150);
rect(this.pos.x, this.pos.y, this.w, this.h);
fill(170, 180, 210);
rect(this.pos.x, this.top + 2, this.w, 4);
fill(255);
textAlign(CENTER, CENTER);
textSize(10);
text("KEY REQUIRED", this.pos.x, this.pos.y);
} else {
fill(80, 55, 0);
rect(this.pos.x, this.pos.y, this.w, this.h);
fill(0, 150, 50);
rect(this.pos.x, this.top + 2, this.w, 4); // grass
}
pop();
}
}
class Checkpoint {
constructor(platform, tip) {
this.platform = platform;
this.x = platform.pos.x;
this.y = platform.top;
this.tip = tip;
this.reached = false;
}
update() {
// reached when the player lands on this checkpoint's platform
if (!this.reached && player.grounded && player.ground === this.platform) this.reach();
}
reach() {
this.reached = true;
tipsFound[this.tip] = true;
if (!lastCheckpoint || this.tip > lastCheckpoint.tip) lastCheckpoint = this;
lastTip = this.tip;
showTip(this.tip);
burst(this.x, this.y - 30, 24, [255, 220, 80], 3);
[523, 659, 784, 1047].forEach((f, i) => sfx(f, "triangle", i * 90));
}
draw() {
if (this.y < camY - 60 || this.y > camY + height + 10) return;
push();
stroke(210);
strokeWeight(2);
line(this.x, this.y, this.x, this.y - 34); // pole
noStroke();
const wave = this.reached ? sin(frameCount * 0.12) * 3 : 0;
fill(this.reached ? color(60, 220, 120) : color(150));
triangle(this.x + 1, this.y - 34, this.x + 1, this.y - 20, this.x + 18 + wave, this.y - 27);
fill(255, 220, 80);
circle(this.x, this.y - 35, 5);
pop();
}
}
class KeyItem {
constructor(x, y) {
this.x = x;
this.y = y;
this.collected = false;
}
update() {
if (this.collected) return;
if (dist(this.x, this.y, player.pos.x, player.pos.y) < 20) {
this.collected = true;
platforms = platforms.filter((p) => p !== lockedPlatform); // open the gate
burst(this.x, this.y, 20, [255, 230, 80], 3);
toast("Key collected! The gate is open.");
sfx(660, "square");
sfx(880, "square", 90);
}
}
draw() {
if (this.collected) return;
const bob = sin(frameCount * 0.08) * 3;
push();
fill("yellow");
stroke("red");
rect(this.x + 2.5, this.y - 15 + bob, 10, 5);
rect(this.x, this.y - 12.5 + bob, 5, 10);
circle(this.x, this.y + bob, 20);
pop();
}
}
class NPC {
constructor(x, y) {
this.x = x;
this.y = y;
this.line = 0;
this.near = false;
}
update() {
this.near = dist(this.x, this.y, player.pos.x, player.pos.y) < 50;
}
talk() {
if (!this.near) return;
this.line = (this.line + 1) % NPC_LINES.length;
sfx(440, "triangle");
}
draw() {
push();
fill(255, 215, 0);
stroke(0);
rect(this.x, this.y, 25, 25, 5);
fill(0);
noStroke();
rect(this.x + (this.x > player.pos.x ? -5 : 5), this.y - 5, 4, 4); // eye follows player
textAlign(CENTER, CENTER);
textSize(12);
if (this.near) {
label(NPC_LINES[this.line] + "\n(press E to talk)", this.x, this.y - 48);
} else {
label("!", this.x, this.y - 22 + sin(frameCount * 0.1) * 2);
}
pop();
}
}
// ============================================================
// Particles
// ============================================================
function burst(x, y, n, col, speed = 2) {
for (let i = 0; i < n; i++) {
particles.push({
x, y,
vx: random(-speed, speed),
vy: random(-speed * 1.2, 0),
g: 0.1,
life: 40,
max: 40,
col,
size: random(2, 4),
});
}
}
function spawnConfetti() {
const palette = [[255, 90, 110], [255, 220, 80], [90, 220, 140], [110, 170, 255]];
particles.push({
x: random(width), y: camY - 5,
vx: random(-0.5, 0.5), vy: random(1, 3),
g: 0.01, life: 200, max: 200,
col: random(palette),
size: random(3, 6),
});
}
function updateParticles() {
for (let i = particles.length - 1; i >= 0; i--) {
const p = particles[i];
p.vy += p.g;
p.x += p.vx;
p.y += p.vy;
p.life--;
if (p.life <= 0) particles.splice(i, 1);
}
}
function drawParticles() {
push();
noStroke();
for (const p of particles) {
fill(p.col[0], p.col[1], p.col[2], (255 * p.life) / p.max);
rect(p.x, p.y, p.size, p.size);
}
pop();
}
// ============================================================
// Drawing helpers & UI
// ============================================================
function drawSky(t) {
background(lerpColor(color(24, 24, 108), color(132, 199, 237), t)); // midnight -> morning
noStroke();
const night = 1 - constrain(t * 1.6, 0, 1);
if (night > 0) {
for (const s of stars) {
fill(255, 255 * night * (0.6 + 0.4 * sin(frameCount * 0.05 + s.p)));
circle(s.x, s.y, s.r * 2);
}
}
const cloudAmt = constrain((t - 0.4) * 2.5, 0, 1);
if (cloudAmt > 0) {
fill(255, 170 * cloudAmt);
for (const c of clouds) {
c.x += c.s;
if (c.x > width + 60) c.x = -60;
ellipse(c.x, c.y, c.w, c.w * 0.35);
ellipse(c.x - c.w * 0.25, c.y + 3, c.w * 0.6, c.w * 0.3);
ellipse(c.x + c.w * 0.25, c.y + 3, c.w * 0.6, c.w * 0.3);
}
}
}
// text with a dark outline so it is readable on any sky colour
function label(str, x, y) {
push();
stroke(0, 160);
strokeWeight(3);
fill(255);
text(str, x, y);
pop();
}
function formatTime(s) {
return nf(floor(s / 60), 2) + ":" + nf(floor(s % 60), 2);
}
function drawMenu() {
drawSky(0);
push();
textAlign(CENTER, CENTER);
fill(255, 210, 60);
textStyle(BOLD);
textSize(40);
text("CLIMB & LEARN", width / 2, 90);
textStyle(NORMAL);
textSize(14);
fill(255);
text("Reach the top and collect study tips on the way.", width / 2, 140);
textSize(13);
fill(210);
text(
"A / D : walk\n" +
"Hold W or Space : charge a jump, release to leap\n" +
"Hold A or D while charging : jump sideways\n" +
"E : talk R : last checkpoint T : replay tip M : mute",
width / 2,
235
);
if (frameCount % 60 < 40) {
fill(255);
textSize(16);
text("Click or press ENTER to start", width / 2, 340);
}
pop();
}
function drawHUD() {
push();
textSize(12);
const lvl = max(1, -floor(player.pos.y / height) + 1);
const found = tipsFound.filter(Boolean).length;
const secs = (state === "win" ? winTime : millis() - runStart) / 1000;
textAlign(LEFT, TOP);
label("Level " + lvl + " Falls " + falls, 10, 8);
textAlign(RIGHT, TOP);
label("Tips " + found + "/" + TIPS.length + " " + formatTime(secs), width - 10, 8);
pop();
}
function showTip(i) {
tipShown = i;
tipTimer = TIP_DURATION;
}
function replayTip() {
if (lastTip >= 0) showTip(lastTip);
else toast("No tips yet. Find a checkpoint flag!");
}
function drawTipPanel() {
if (tipTimer <= 0) return;
tipTimer--;
const t = TIPS[tipShown];
const alpha = min(255, tipTimer * 4); // fade out at the end
const slide = tipTimer > TIP_DURATION - 15 ? map(tipTimer, TIP_DURATION, TIP_DURATION - 15, 40, 0) : 0;
push();
rectMode(CORNER);
textAlign(LEFT, TOP);
translate(0, slide);
noStroke();
fill(10, 15, 40, alpha * 0.88);
rect(20, height - 92, width - 40, 80, 10);
fill(255, 210, 60, alpha);
textStyle(BOLD);
textSize(13);
text("STUDY TIP " + (tipShown + 1) + "/" + TIPS.length + " - " + t.title, 34, height - 84);
fill(255, alpha);
textStyle(NORMAL);
text(t.text, 34, height - 62, width - 68, 48);
pop();
}
function toast(msg) {
toastText = msg;
toastTimer = 120;
}
function drawToast() {
if (toastTimer <= 0) return;
toastTimer--;
const a = min(255, toastTimer * 6);
push();
textAlign(CENTER, CENTER);
textStyle(BOLD);
textSize(14);
stroke(0, a * 0.6);
strokeWeight(3);
fill(255, 230, 120, a);
text(toastText, width / 2, 60);
pop();
}
function drawWinOverlay() {
push();
rectMode(CORNER);
noStroke();
fill(0, 0, 0, 175);
rect(40, 40, width - 80, height - 80, 12);
textAlign(CENTER, TOP);
fill(255, 210, 60);
textStyle(BOLD);
textSize(28);
text("YOU MADE IT!", width / 2, 55);
textStyle(NORMAL);
textSize(13);
fill(255);
text("Time " + formatTime(winTime / 1000) + " Falls " + falls, width / 2, 95);
textAlign(LEFT, TOP);
const found = tipsFound.filter(Boolean).length;
text("Study tips collected: " + found + "/" + TIPS.length, 70, 125);
for (let i = 0; i < TIPS.length; i++) {
if (tipsFound[i]) {
fill(120, 230, 150);
text("\u2713 " + TIPS[i].title, 70, 148 + i * 20);
} else {
fill(150);
text("? ???", 70, 148 + i * 20);
}
}
textAlign(CENTER, TOP);
fill(255, 210, 60);
text("Try to recall all the tips without looking!", width / 2, 285);
if (frameCount % 60 < 40) {
fill(255);
text("Click or press ENTER to play again", width / 2, 322);
}
pop();
}